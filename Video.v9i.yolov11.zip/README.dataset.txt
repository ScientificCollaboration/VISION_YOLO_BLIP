# Video > 2025-06-28 10:57pm
https://universe.roboflow.com/aalex11/video-ytrrz

Provided by a Roboflow user
License: CC BY 4.0

